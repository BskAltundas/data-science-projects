# Machine Learning Projects

This folder includes ML homework and mini-projects (classification, regression, clustering, etc.).