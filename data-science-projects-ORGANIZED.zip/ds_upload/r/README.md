# R Projects

R scripts / R Markdown assignments for data analysis and statistics.