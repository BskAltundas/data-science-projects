# Python Projects

This folder contains Python assignments and notebooks (EDA, utilities, scripts).